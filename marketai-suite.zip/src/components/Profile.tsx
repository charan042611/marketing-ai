import { useState } from 'react';
import { User, Mail, Briefcase, Building, Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Profile() {
  const { t } = useLanguage();
  const [isSaved, setIsSaved] = useState(false);
  const [formData, setFormData] = useState({
    name: 'Alex Johnson',
    email: 'alex.johnson@example.com',
    role: 'Marketing Director',
    company: 'TechGrowth Inc.'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden max-w-2xl mx-auto transition-colors duration-300">
      <div className="p-8 md:p-12">
        <h2 className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mb-2 flex items-center gap-3">
          <User className="w-8 h-8" />
          {t('profileTitle')}
        </h2>
        <p className="text-slate-500 dark:text-slate-400 mb-8">{t('profileDesc')}</p>
        
        <div className="space-y-6">
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              <User className="w-4 h-4 mr-2" />
              {t('name')}
            </label>
            <input 
              type="text" 
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
            />
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              <Mail className="w-4 h-4 mr-2" />
              {t('email')}
            </label>
            <input 
              type="email" 
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
            />
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              <Briefcase className="w-4 h-4 mr-2" />
              {t('role')}
            </label>
            <input 
              type="text" 
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
            />
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              <Building className="w-4 h-4 mr-2" />
              {t('company')}
            </label>
            <input 
              type="text" 
              name="company"
              value={formData.company}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
            />
          </div>

          <div className="pt-4">
            <button 
              onClick={handleSave}
              className="w-full relative bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors overflow-hidden"
            >
              <span className={`transition-opacity duration-300 ${isSaved ? 'opacity-0' : 'opacity-100'}`}>
                {t('saveProfile')}
              </span>
              <span className={`absolute inset-0 flex items-center justify-center bg-emerald-500 transition-opacity duration-300 ${isSaved ? 'opacity-100' : 'opacity-0'}`}>
                <Check className="w-5 h-5 mr-2" />
                {t('profileSaved')}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
