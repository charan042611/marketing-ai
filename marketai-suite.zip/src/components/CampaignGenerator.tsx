import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import { Twitter, Instagram, Facebook, Mail, Youtube, MessageCircle } from 'lucide-react';
import Tooltip from './Tooltip';
import CameraInput from './CameraInput';
import MicButton from './MicButton';
import { useLanguage } from '../contexts/LanguageContext';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function CampaignGenerator() {
  const [productName, setProductName] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [platform, setPlatform] = useState('');
  const [location, setLocation] = useState('');
  const [productImage, setProductImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isCleared, setIsCleared] = useState(false);
  const [chartData, setChartData] = useState<any[]>([]);
  const { language, t } = useLanguage();

  const commonPlatforms = [
    { name: 'Twitter', icon: Twitter },
    { name: 'Instagram', icon: Instagram },
    { name: 'Facebook', icon: Facebook },
    { name: 'Email', icon: Mail },
    { name: 'YouTube', icon: Youtube },
    { name: 'WhatsApp', icon: MessageCircle }
  ];

  const handleClear = () => {
    setProductName('');
    setTargetAudience('');
    setPlatform('');
    setLocation('');
    setProductImage(null);
    setResult('');
    setImageUrl('');
    setChartData([]);
    setIsCleared(true);
    setTimeout(() => setIsCleared(false), 2000);
  };

  const handleGenerate = async () => {
    if (!productName || !targetAudience || !platform || !location) return;
    
    setLoading(true);
    setResult('');
    setImageUrl('');
    setChartData([]);
    
    try {
      const prompt = `Generate a comprehensive marketing campaign strategy for the following:
Product: ${productName}
Target Audience: ${targetAudience}
Platform: ${platform}
Target Location: ${location}
${productImage ? 'Note: A product image has been provided. Please incorporate its visual elements into the strategy.' : ''}

Please include:
1. Campaign Objectives
2. 5 targeted content ideas tailored to the local culture and trends of ${location}
3. 3 variations of compelling ad copy (Problem-Agitate-Solve, Social Proof, Limited-Time Offer)
4. Specific call-to-action suggestions tailored to the platform's audience behavior in ${location}.

Please provide the entire response in ${language}.`;

      const contents: any[] = [{ text: prompt }];
      if (productImage) {
        const base64Data = productImage.split(',')[1];
        const mimeType = productImage.split(';')[0].split(':')[1];
        contents.unshift({
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        });
      }

      const textPromise = ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: contents },
      });

      const imagePrompt = `A professional marketing promotional image for a product called ${productName} targeting ${targetAudience}. High quality, modern, clean, no text.`;
      const imagePromise = ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: imagePrompt,
      }).catch(err => {
        console.error("Image generation failed:", err);
        return null;
      });

      const [textResponse, imageResponse] = await Promise.all([textPromise, imagePromise]);
      
      setResult(textResponse.text || '');
      
      // Mock chart data based on inputs
      setChartData([
        { name: 'Week 1', engagement: Math.floor(Math.random() * 5000) + 1000 },
        { name: 'Week 2', engagement: Math.floor(Math.random() * 8000) + 3000 },
        { name: 'Week 3', engagement: Math.floor(Math.random() * 12000) + 5000 },
        { name: 'Week 4', engagement: Math.floor(Math.random() * 15000) + 8000 },
      ]);

      if (imageResponse) {
        let genImageUrl = '';
        const parts = imageResponse.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
          if (part.inlineData) {
            genImageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          }
        }
        setImageUrl(genImageUrl);
      }
    } catch (error) {
      console.error(error);
      setResult('Error generating campaign. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden max-w-4xl mx-auto transition-colors duration-300">
      <div className="p-8 md:p-12">
        <h2 className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mb-2">{t('campaignTitle')}</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-8">{t('campaignDesc')}</p>
        
        <div className="space-y-6">
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('productImage')}
              <Tooltip content="Upload or take a photo of your product to enhance the AI's context." />
            </label>
            <CameraInput onImageCaptured={setProductImage} />
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('productName')}
              <Tooltip content="Enter the product or service name. Example: AI Analytics Platform" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g., AI Analytics Platform"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setProductName(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('targetAudience')}
              <Tooltip content="Describe who you are trying to reach. Example: Health-conscious millennials" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="e.g., Health-conscious millennials, Enterprises"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setTargetAudience(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('platform')}
              <Tooltip content="Where will this campaign run? Example: LinkedIn, Instagram, Email" />
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {commonPlatforms.map(p => (
                <button
                  key={p.name}
                  onClick={() => setPlatform(p.name)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-2 ${
                    platform === p.name 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <p.icon className="w-4 h-4" />
                  {p.name}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                placeholder="e.g., LinkedIn, Instagram, Twitter, Email"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setPlatform(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('targetLocation')}
              <Tooltip content="Where are you targeting this campaign? Example: New York City, Global, Europe" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., New York City, Global, Europe"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setLocation(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div className="flex gap-4 pt-4">
            <button 
              onClick={handleGenerate}
              disabled={loading || !productName || !targetAudience || !platform || !location}
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Generating...' : t('generateCampaign')}
            </button>
            <button 
              onClick={handleClear}
              className="flex-1 relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold py-3 px-6 rounded-xl transition-colors overflow-hidden"
            >
              <span className={`transition-opacity duration-300 ${isCleared ? 'opacity-0' : 'opacity-100'}`}>{t('clear')}</span>
              <span className={`absolute inset-0 flex items-center justify-center text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 transition-opacity duration-300 ${isCleared ? 'opacity-100' : 'opacity-0'}`}>
                {t('cleared')}
              </span>
            </button>
          </div>
        </div>
      </div>
      
      {result && (
        <div className="bg-slate-50 dark:bg-slate-800/50 p-8 md:p-12 border-t border-slate-100 dark:border-slate-800 transition-colors duration-300">
          <h3 className="text-sm font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-6">Your Campaign Strategy</h3>
          
          {chartData.length > 0 && (
            <div className="mb-10 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700">
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-6 text-center">Projected Engagement Over Time</h4>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" opacity={0.2} />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <RechartsTooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                      itemStyle={{ color: '#818cf8' }}
                    />
                    <Bar dataKey="engagement" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {imageUrl && (
            <div className="mb-8 rounded-2xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-700">
              <img src={imageUrl} alt="Generated Campaign Visual" className="w-full h-auto object-cover max-h-96" />
            </div>
          )}
          <div className="prose prose-indigo dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}
