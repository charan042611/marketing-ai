import { useState, useRef } from 'react';
import { Camera, Upload, X } from 'lucide-react';

export default function CameraInput({ onImageCaptured }: { onImageCaptured: (base64: string | null) => void }) {
  const [image, setImage] = useState<string | null>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const uploadInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImage(base64String);
        onImageCaptured(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClear = () => {
    setImage(null);
    onImageCaptured(null);
    if (cameraInputRef.current) cameraInputRef.current.value = '';
    if (uploadInputRef.current) uploadInputRef.current.value = '';
  };

  return (
    <div className="w-full">
      {image ? (
        <div className="relative w-full h-48 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">
          <img src={image} alt="Captured product" className="w-full h-full object-cover" />
          <button 
            onClick={handleClear}
            className="absolute top-2 right-2 bg-slate-900/50 hover:bg-slate-900/80 text-white p-1.5 rounded-full backdrop-blur-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="flex gap-4">
          <div 
            onClick={() => cameraInputRef.current?.click()}
            className="flex-1 h-32 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 transition-colors group"
          >
            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-full mb-2 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50 transition-colors">
              <Camera className="w-6 h-6 text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400" />
            </div>
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
              Take Photo
            </span>
            <input 
              type="file" 
              accept="image/*" 
              capture="environment" 
              className="hidden" 
              ref={cameraInputRef}
              onChange={handleFileChange}
            />
          </div>

          <div 
            onClick={() => uploadInputRef.current?.click()}
            className="flex-1 h-32 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 transition-colors group"
          >
            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-full mb-2 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50 transition-colors">
              <Upload className="w-6 h-6 text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400" />
            </div>
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
              Upload Image
            </span>
            <input 
              type="file" 
              accept="image/*" 
              className="hidden" 
              ref={uploadInputRef}
              onChange={handleFileChange}
            />
          </div>
        </div>
      )}
    </div>
  );
}
