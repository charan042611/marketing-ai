import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import { Twitter, Instagram, Facebook, Mail, Youtube, MessageCircle } from 'lucide-react';
import Tooltip from './Tooltip';
import CameraInput from './CameraInput';
import MicButton from './MicButton';
import { useLanguage } from '../contexts/LanguageContext';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function PitchGenerator() {
  const [productName, setProductName] = useState('');
  const [customerPersona, setCustomerPersona] = useState('');
  const [location, setLocation] = useState('');
  const [platform, setPlatform] = useState('');
  const [productImage, setProductImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isCleared, setIsCleared] = useState(false);
  const [chartData, setChartData] = useState<any[]>([]);
  const { language, t } = useLanguage();

  const commonPlatforms = [
    { name: 'Twitter', icon: Twitter },
    { name: 'Instagram', icon: Instagram },
    { name: 'Facebook', icon: Facebook },
    { name: 'Email', icon: Mail },
    { name: 'YouTube', icon: Youtube },
    { name: 'WhatsApp', icon: MessageCircle }
  ];

  const handleClear = () => {
    setProductName('');
    setCustomerPersona('');
    setLocation('');
    setPlatform('');
    setProductImage(null);
    setResult('');
    setImageUrl('');
    setChartData([]);
    setIsCleared(true);
    setTimeout(() => setIsCleared(false), 2000);
  };

  const handleGenerate = async () => {
    if (!productName || !customerPersona || !location) return;
    
    setLoading(true);
    setResult('');
    setImageUrl('');
    setChartData([]);
    
    try {
      const prompt = `Create a personalized, compelling sales pitch for the following:
Product: ${productName}
Customer Persona: ${customerPersona}
Target Location: ${location}
Delivery Platform: ${platform || 'General'}
${productImage ? 'Note: A product image has been provided. Please incorporate its visual elements into the pitch.' : ''}

Please include:
1. 30-Second Pitch: Concise, engaging elevator pitch tailored to the business environment in ${location} and formatted for ${platform || 'general use'}
2. Value Proposition: Clear statement of value and business benefits
3. Differentiators: Key advantages versus competitive alternatives
4. Call-To-Action: Next steps to move deal forward (demo, meeting, trial)

Please provide the entire response in ${language}.`;

      const contents: any[] = [{ text: prompt }];
      if (productImage) {
        const base64Data = productImage.split(',')[1];
        const mimeType = productImage.split(';')[0].split(':')[1];
        contents.unshift({
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        });
      }

      const textPromise = ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: contents },
      });

      const imagePrompt = `A professional corporate presentation slide background or conceptual visualization for a product called ${productName} being pitched to ${customerPersona}. Sleek, modern business environment, high quality, no text.`;
      const imagePromise = ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: imagePrompt,
      }).catch(err => {
        console.error("Image generation failed:", err);
        return null;
      });

      const [textResponse, imageResponse] = await Promise.all([textPromise, imagePromise]);
      
      setResult(textResponse.text || '');

      // Mock chart data based on inputs
      setChartData([
        { stage: 'Initial Contact', probability: 20 },
        { stage: 'Discovery', probability: 45 },
        { stage: 'Proposal', probability: 65 },
        { stage: 'Negotiation', probability: 85 },
        { stage: 'Closed Won', probability: 95 },
      ]);

      if (imageResponse) {
        let genImageUrl = '';
        const parts = imageResponse.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
          if (part.inlineData) {
            genImageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          }
        }
        setImageUrl(genImageUrl);
      }
    } catch (error) {
      console.error(error);
      setResult('Error generating pitch. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden max-w-4xl mx-auto transition-colors duration-300">
      <div className="p-8 md:p-12">
        <h2 className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">{t('pitchTitle')}</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-8">{t('pitchDesc')}</p>
        
        <div className="space-y-6">
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('productImage')}
              <Tooltip content="Upload or take a photo of your product to enhance the AI's context." />
            </label>
            <CameraInput onImageCaptured={setProductImage} />
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('productName')}
              <Tooltip content="The product or solution you are selling. Example: Cloud-based inventory system" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g., Cloud-based inventory management system"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setProductName(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('customerPersona')}
              <Tooltip content="Describe the person you are pitching to. Example: Operations Director at Fortune 500" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={customerPersona}
                onChange={(e) => setCustomerPersona(e.target.value)}
                placeholder="e.g., Operations Director, Fortune 500 retail company"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setCustomerPersona(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('targetLocation')}
              <Tooltip content="Where is the prospect located? Example: San Francisco, Tokyo, Latin America" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., San Francisco, Tokyo, Latin America"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setLocation(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('deliveryPlatform')}
              <Tooltip content="Where will you deliver this pitch? Example: Email, LinkedIn, WhatsApp" />
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {commonPlatforms.map(p => (
                <button
                  key={p.name}
                  onClick={() => setPlatform(p.name)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-2 ${
                    platform === p.name 
                      ? 'bg-purple-600 text-white shadow-md' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <p.icon className="w-4 h-4" />
                  {p.name}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                placeholder="e.g., Email, LinkedIn, WhatsApp"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setPlatform(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div className="flex gap-4 pt-4">
            <button 
              onClick={handleGenerate}
              disabled={loading || !productName || !customerPersona || !location}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Generating...' : t('generatePitch')}
            </button>
            <button 
              onClick={handleClear}
              className="flex-1 relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold py-3 px-6 rounded-xl transition-colors overflow-hidden"
            >
              <span className={`transition-opacity duration-300 ${isCleared ? 'opacity-0' : 'opacity-100'}`}>{t('clear')}</span>
              <span className={`absolute inset-0 flex items-center justify-center text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 transition-opacity duration-300 ${isCleared ? 'opacity-100' : 'opacity-0'}`}>
                {t('cleared')}
              </span>
            </button>
          </div>
        </div>
      </div>
      
      {result && (
        <div className="bg-slate-50 dark:bg-slate-800/50 p-8 md:p-12 border-t border-slate-100 dark:border-slate-800 transition-colors duration-300">
          <h3 className="text-sm font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider mb-6">Your Sales Pitch</h3>
          
          {chartData.length > 0 && (
            <div className="mb-10 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700">
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-6 text-center">Expected Conversion Probability by Stage</h4>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorProb" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#a855f7" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" opacity={0.2} />
                    <XAxis dataKey="stage" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <RechartsTooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                      itemStyle={{ color: '#c084fc' }}
                    />
                    <Area type="monotone" dataKey="probability" stroke="#a855f7" fillOpacity={1} fill="url(#colorProb)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {imageUrl && (
            <div className="mb-8 rounded-2xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-700">
              <img src={imageUrl} alt="Generated Pitch Visual" className="w-full h-auto object-cover max-h-96" />
            </div>
          )}
          <div className="prose prose-purple dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}
