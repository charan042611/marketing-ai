import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';
import { Twitter, Instagram, Facebook, Mail, Youtube, MessageCircle } from 'lucide-react';
import Tooltip from './Tooltip';
import MicButton from './MicButton';
import { useLanguage } from '../contexts/LanguageContext';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function LeadQualifier() {
  const [leadName, setLeadName] = useState('');
  const [budget, setBudget] = useState('');
  const [need, setNeed] = useState('');
  const [urgency, setUrgency] = useState('');
  const [platform, setPlatform] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [isCleared, setIsCleared] = useState(false);
  const [chartData, setChartData] = useState<any[]>([]);
  const { language, t } = useLanguage();

  const commonPlatforms = [
    { name: 'Twitter', icon: Twitter },
    { name: 'Instagram', icon: Instagram },
    { name: 'Facebook', icon: Facebook },
    { name: 'Email', icon: Mail },
    { name: 'YouTube', icon: Youtube },
    { name: 'WhatsApp', icon: MessageCircle }
  ];

  const handleClear = () => {
    setLeadName('');
    setBudget('');
    setNeed('');
    setUrgency('');
    setPlatform('');
    setResult('');
    setChartData([]);
    setIsCleared(true);
    setTimeout(() => setIsCleared(false), 2000);
  };

  const handleGenerate = async () => {
    if (!leadName || !budget || !need || !urgency) return;
    
    setLoading(true);
    setResult('');
    setChartData([]);
    
    try {
      const prompt = `Analyze and score the following lead:
Lead Name: ${leadName}
Budget: ${budget}
Business Need: ${need}
Urgency: ${urgency}
Lead Source/Platform: ${platform || 'Unknown'}

Please evaluate this lead across Budget, Need, Urgency, and Authority dimensions and provide:
1. Lead Qualification Score: A numeric score from 0-100
2. Scoring Reasoning: Detailed explanation of the score calculation
3. Probability of Conversion: Estimated likelihood of deal closure (%)

Please provide the entire response in ${language}.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      
      setResult(response.text || '');

      // Mock chart data based on inputs
      setChartData([
        { subject: 'Budget', A: Math.floor(Math.random() * 60) + 40, fullMark: 100 },
        { subject: 'Authority', A: Math.floor(Math.random() * 60) + 40, fullMark: 100 },
        { subject: 'Need', A: Math.floor(Math.random() * 60) + 40, fullMark: 100 },
        { subject: 'Timing', A: Math.floor(Math.random() * 60) + 40, fullMark: 100 },
        { subject: 'Fit', A: Math.floor(Math.random() * 60) + 40, fullMark: 100 },
      ]);
    } catch (error) {
      console.error(error);
      setResult('Error scoring lead. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden max-w-4xl mx-auto transition-colors duration-300">
      <div className="p-8 md:p-12">
        <h2 className="text-3xl font-bold text-fuchsia-600 dark:text-fuchsia-400 mb-2">{t('leadTitle')}</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-8">{t('leadDesc')}</p>
        
        <div className="space-y-6">
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('leadName')}
              <Tooltip content="The name of the potential customer or company. Example: Sarah Johnson" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={leadName}
                onChange={(e) => setLeadName(e.target.value)}
                placeholder="e.g., Sarah Johnson"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setLeadName(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('budget')}
              <Tooltip content="Information about the lead's budget. Example: $150,000 annual software budget" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder="e.g., $150,000 annual software budget"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setBudget(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('businessNeed')}
              <Tooltip content="The specific problem the lead is trying to solve. Example: Improving customer retention by 20%" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={need}
                onChange={(e) => setNeed(e.target.value)}
                placeholder="e.g., Improving customer retention by 20%"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setNeed(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('urgency')}
              <Tooltip content="How quickly the lead needs a solution. Example: Board requested solution by end of Q3" />
            </label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={urgency}
                onChange={(e) => setUrgency(e.target.value)}
                placeholder="e.g., Board requested solution by end of Q3"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setUrgency(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>

          <div>
            <label className="flex items-center text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {t('leadSource')}
              <Tooltip content="Where did this lead come from? Example: Email, Twitter, LinkedIn" />
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {commonPlatforms.map(p => (
                <button
                  key={p.name}
                  onClick={() => setPlatform(p.name)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-2 ${
                    platform === p.name 
                      ? 'bg-fuchsia-600 text-white shadow-md' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <p.icon className="w-4 h-4" />
                  {p.name}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                placeholder="e.g., Email, Twitter, LinkedIn"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 bg-slate-50 dark:bg-slate-800 dark:text-white transition-colors"
              />
              <MicButton onResult={(text) => setPlatform(prev => (prev + ' ' + text).trim())} />
            </div>
          </div>
          
          <div className="flex gap-4 pt-4">
            <button 
              onClick={handleGenerate}
              disabled={loading || !leadName || !budget || !need || !urgency}
              className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Scoring...' : t('scoreLead')}
            </button>
            <button 
              onClick={handleClear}
              className="flex-1 relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold py-3 px-6 rounded-xl transition-colors overflow-hidden"
            >
              <span className={`transition-opacity duration-300 ${isCleared ? 'opacity-0' : 'opacity-100'}`}>{t('clear')}</span>
              <span className={`absolute inset-0 flex items-center justify-center text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 transition-opacity duration-300 ${isCleared ? 'opacity-100' : 'opacity-0'}`}>
                {t('cleared')}
              </span>
            </button>
          </div>
        </div>
      </div>
      
      {result && (
        <div className="bg-slate-50 dark:bg-slate-800/50 p-8 md:p-12 border-t border-slate-100 dark:border-slate-800 transition-colors duration-300">
          <h3 className="text-sm font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-wider mb-6">Lead Qualification Analysis</h3>
          
          {chartData.length > 0 && (
            <div className="mb-10 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700">
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-6 text-center">BANT Qualification Radar</h4>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                    <PolarGrid stroke="#cbd5e1" opacity={0.3} />
                    <PolarAngleAxis dataKey="subject" stroke="#94a3b8" fontSize={12} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#94a3b8" opacity={0.5} />
                    <RechartsTooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                      itemStyle={{ color: '#d946ef' }}
                    />
                    <Radar name="Score" dataKey="A" stroke="#d946ef" fill="#d946ef" fillOpacity={0.5} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          <div className="prose prose-fuchsia dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}
