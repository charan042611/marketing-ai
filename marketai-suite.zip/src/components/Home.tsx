import { Rocket, Mic, Star, TrendingUp, Clock, Users, Zap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Home({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col items-center justify-center py-8 text-center space-y-20">
      {/* Hero Section */}
      <div className="space-y-6 max-w-4xl">
        <h2 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-4">
          {t('welcome')}
        </h2>
        <p className="text-xl text-white/80 max-w-2xl mx-auto leading-relaxed">
          {t('subtitle')}
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full max-w-5xl">
        {[
          { icon: TrendingUp, label: "Avg. Conversion Lift", value: "32%" },
          { icon: Clock, label: "Hours Saved Weekly", value: "15+" },
          { icon: Users, label: "Active Marketers", value: "10k+" },
          { icon: Zap, label: "Campaigns Generated", value: "1M+" },
        ].map((stat, i) => (
          <div key={i} className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-3xl flex flex-col items-center justify-center hover:bg-white/20 transition-colors">
            <stat.icon className="w-8 h-8 text-emerald-300 mb-4" />
            <div className="text-4xl font-bold text-white mb-1">{stat.value}</div>
            <div className="text-sm text-white/70 font-medium uppercase tracking-wider">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* About Section */}
      <div className="w-full max-w-5xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row text-left transition-colors duration-300">
        <div className="md:w-1/2 p-10 md:p-12 flex flex-col justify-center">
          <div className="inline-block px-4 py-1.5 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 font-semibold rounded-full text-sm mb-6 w-max">
            About MarketAI Suite
          </div>
          <h3 className="text-3xl font-bold mb-4">Data-Driven Marketing at Scale</h3>
          <p className="text-slate-600 dark:text-slate-400 mb-6 leading-relaxed">
            MarketAI Suite transforms sales and marketing operations into an intelligent, data-driven experience. By analyzing product information, target demographics, and lead attributes, our platform generates evidence-based strategies that convert.
          </p>
          <ul className="space-y-4 mb-8">
            {[
              "Predictive lead scoring & qualification",
              "Automated, personalized sales pitches",
              "Multi-platform campaign generation",
              "Real-time analytics and insights"
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-3 text-slate-700 dark:text-slate-300 font-medium">
                <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                </div>
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="md:w-1/2 relative min-h-[300px]">
          <img 
            src="https://picsum.photos/seed/analytics/800/800" 
            alt="Analytics Dashboard" 
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white dark:from-slate-900 via-white/40 dark:via-slate-900/40 to-transparent md:block hidden"></div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="w-full max-w-5xl space-y-8">
        <div className="text-center space-y-4">
          <h3 className="text-3xl font-bold">Our Core Features</h3>
          <p className="text-white/70 max-w-2xl mx-auto">Select a tool below to start optimizing your marketing workflow.</p>
        </div>
        
        <div className="w-full space-y-6">
          <div 
            onClick={() => onNavigate('campaign')}
            className="relative w-full h-64 md:h-80 rounded-3xl overflow-hidden cursor-pointer group shadow-2xl border border-white/10"
          >
            <img 
              src="https://picsum.photos/seed/marketing/1200/600?blur=2" 
              alt="Campaign Generator"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/90 via-indigo-900/40 to-transparent flex flex-col items-center justify-end pb-10">
              <div className="bg-white/20 backdrop-blur-md p-4 rounded-full mb-4 group-hover:bg-white/30 transition-colors shadow-lg">
                <Rocket className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-white mb-2">Launch Your Next Campaign</h3>
              <p className="text-white/80 font-medium">Click here to start generating AI-powered marketing strategies</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div 
              onClick={() => onNavigate('pitch')}
              className="relative h-64 rounded-3xl overflow-hidden cursor-pointer group shadow-2xl border border-white/10"
            >
              <img 
                src="https://picsum.photos/seed/pitch/800/400?blur=2" 
                alt="Sales Pitch Creator"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/90 via-purple-900/40 to-transparent flex flex-col items-center justify-end pb-8">
                <div className="bg-white/20 backdrop-blur-md p-4 rounded-full mb-4 group-hover:bg-white/30 transition-colors shadow-lg flex gap-2">
                  <Mic className="w-8 h-8 text-white" />
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Create Sales Pitches</h3>
                <p className="text-white/80 font-medium">Craft compelling, personalized pitches</p>
              </div>
            </div>

            <div 
              onClick={() => onNavigate('lead')}
              className="relative h-64 rounded-3xl overflow-hidden cursor-pointer group shadow-2xl border border-white/10"
            >
              <img 
                src="https://picsum.photos/seed/lead/800/400?blur=2" 
                alt="Lead Qualifier"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-fuchsia-900/90 via-fuchsia-900/40 to-transparent flex flex-col items-center justify-end pb-8">
                <div className="bg-white/20 backdrop-blur-md p-4 rounded-full mb-4 group-hover:bg-white/30 transition-colors shadow-lg flex gap-2">
                  <Star className="w-8 h-8 text-white" />
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Qualify Your Leads</h3>
                <p className="text-white/80 font-medium">Score and prioritize high-value leads</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
