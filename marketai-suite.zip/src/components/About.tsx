import { CheckCircle2, Zap, Target, BarChart3, MapPin } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-3xl shadow-2xl overflow-hidden max-w-5xl mx-auto transition-colors duration-300">
      {/* Header Banner */}
      <div className="relative h-64 md:h-80 bg-slate-900 flex items-center justify-center overflow-hidden">
        <img 
          src="https://picsum.photos/seed/about/1200/600?blur=4" 
          alt="About MarketAI Suite"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="relative z-10 text-center px-4">
          <div className="inline-block px-4 py-1.5 bg-indigo-500/30 text-indigo-200 font-semibold rounded-full text-sm mb-4 backdrop-blur-md border border-indigo-400/30">
            Platform Overview
          </div>
          <h2 className="text-4xl md:text-6xl font-extrabold text-white mb-4 tracking-tight">About MarketAI Suite</h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Empowering sales and marketing teams with intelligent, data-driven insights.
          </p>
        </div>
      </div>

      <div className="p-8 md:p-12 space-y-16">
        {/* Mission Section */}
        <section className="max-w-3xl mx-auto text-center space-y-6">
          <h3 className="text-3xl font-bold text-slate-900 dark:text-white">Our Mission</h3>
          <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
            MarketAI Suite addresses the challenge of data-driven marketing and sales optimization by delivering AI-powered campaign generation, intelligent pitch creation, and predictive lead scoring. We transform operations into an intelligent experience through a modern interface and comprehensive feature set.
          </p>
        </section>

        {/* Core Scenarios */}
        <section className="space-y-8">
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white text-center mb-10">How It Works</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-slate-50 dark:bg-slate-800 p-8 rounded-2xl border border-slate-100 dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="bg-indigo-100 dark:bg-indigo-900/50 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Target className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <h4 className="text-xl font-bold mb-3 dark:text-white">1. Marketing Campaigns</h4>
              <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                Analyze product details, target audience demographics, and platform specifications to generate a comprehensive marketing strategy including objectives, content ideas, and compelling ad copy variations.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 p-8 rounded-2xl border border-slate-100 dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="bg-purple-100 dark:bg-purple-900/50 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h4 className="text-xl font-bold mb-3 dark:text-white">2. Sales Pitch Generation</h4>
              <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                Create personalized, compelling pitches including a concise elevator pitch, clear value proposition, and key differentiators that address enterprise pain points and move prospects to the next stage.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 p-8 rounded-2xl border border-slate-100 dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="bg-fuchsia-100 dark:bg-fuchsia-900/50 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <BarChart3 className="w-6 h-6 text-fuchsia-600 dark:text-fuchsia-400" />
              </div>
              <h4 className="text-xl font-bold mb-3 dark:text-white">3. Lead Qualification</h4>
              <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                Analyze lead attributes across multiple qualification dimensions (Budget, Need, Urgency) to generate a quantified lead score, detailed reasoning, and probability of conversion assessment.
              </p>
            </div>
          </div>
        </section>

        {/* Technology Stack */}
        <section className="bg-slate-900 text-white rounded-3xl p-10 md:p-12 flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/2 space-y-6">
            <h3 className="text-3xl font-bold">Powered by Advanced AI</h3>
            <p className="text-slate-300 leading-relaxed">
              Built on a modern technology stack, MarketAI Suite leverages state-of-the-art generative AI models to analyze complex business data and return actionable intelligence in seconds.
            </p>
            <ul className="space-y-3">
              {[
                "Google Gemini AI for advanced reasoning",
                "React & Vite for lightning-fast UI",
                "Tailwind CSS for responsive design",
                "Secure OAuth Authentication"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-slate-200">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="md:w-1/2 w-full">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 p-6 rounded-2xl backdrop-blur-sm border border-white/10 text-center">
                <div className="text-3xl font-bold text-emerald-400 mb-1">99.9%</div>
                <div className="text-xs text-slate-400 uppercase tracking-wider">Uptime</div>
              </div>
              <div className="bg-white/10 p-6 rounded-2xl backdrop-blur-sm border border-white/10 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-1">&lt;2s</div>
                <div className="text-xs text-slate-400 uppercase tracking-wider">Response Time</div>
              </div>
              <div className="bg-white/10 p-6 rounded-2xl backdrop-blur-sm border border-white/10 text-center col-span-2">
                <div className="text-3xl font-bold text-purple-400 mb-1">Enterprise</div>
                <div className="text-xs text-slate-400 uppercase tracking-wider">Grade Security</div>
              </div>
            </div>
          </div>
        </section>

        {/* Global Presence */}
        <section className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h3 className="text-3xl font-bold text-slate-900 dark:text-white">Our Global Presence</h3>
            <p className="text-lg text-slate-600 dark:text-slate-400">
              MarketAI Suite powers sales and marketing teams across the globe.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { city: "San Francisco", region: "North America" },
              { city: "London", region: "Europe" },
              { city: "Singapore", region: "Asia Pacific" },
              { city: "Sydney", region: "Oceania" }
            ].map((loc, i) => (
              <div key={i} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors group">
                <div className="bg-white dark:bg-slate-700 w-12 h-12 rounded-full flex items-center justify-center mb-4 shadow-sm group-hover:shadow-md transition-shadow">
                  <MapPin className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white">{loc.city}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider mt-1">{loc.region}</p>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="max-w-3xl mx-auto space-y-8">
          <h3 className="text-3xl font-bold text-slate-900 dark:text-white text-center mb-10">Frequently Asked Questions</h3>
          <div className="space-y-6">
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700">
              <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-2">How does the Campaign Generator create its strategies?</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                The Campaign Generator uses Google's advanced Gemini AI models to analyze your product, target audience, and chosen platform. It then synthesizes this information against proven marketing frameworks to produce tailored objectives, content ideas, and ad copy variations designed specifically for your use case.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700">
              <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Can I use the generated images for my actual marketing?</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Yes! The images generated alongside your campaigns and pitches are created using state-of-the-art image generation models. They are intended to serve as high-quality conceptual visuals, presentation backgrounds, or starting points for your creative team.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700">
              <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-2">How accurate is the Lead Qualifier scoring?</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                The Lead Qualifier evaluates prospects based on established sales methodologies (like BANT - Budget, Authority, Need, Timing). While the AI provides a highly educated assessment and probability score based on the data you input, it should be used as a prioritization tool alongside your team's professional judgment.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
