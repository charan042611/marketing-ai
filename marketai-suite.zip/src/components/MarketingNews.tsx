import { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import { Newspaper, RefreshCw } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function MarketingNews() {
  const [news, setNews] = useState('');
  const [loading, setLoading] = useState(false);
  const { language, t } = useLanguage();

  const fetchNews = async () => {
    setLoading(true);
    try {
      const prompt = `Search Google News for the latest daily updates and news about marketing, digital marketing, and advertising. Summarize the top 5 most important stories. For each story, provide a headline, a brief summary, and the source. Please translate the entire response, including all headlines and summaries, into ${language}.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        }
      });
      
      setNews(response.text || t('noNewsFound'));
    } catch (error) {
      console.error(error);
      setNews(t('failedToFetchNews'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [language]);

  return (
    <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden max-w-4xl mx-auto transition-colors duration-300">
      <div className="p-8 md:p-12">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2 flex items-center gap-3">
              <Newspaper className="w-8 h-8" />
              {t('newsTitle')}
            </h2>
            <p className="text-slate-500 dark:text-slate-400">{t('newsDesc')}</p>
          </div>
          <button 
            onClick={fetchNews}
            disabled={loading}
            className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors disabled:opacity-50"
            title={t('refreshNews')}
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {loading && !news ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="animate-pulse">
                <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-3"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-full mb-2"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-5/6"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="prose prose-blue dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
            <ReactMarkdown>{news}</ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}
