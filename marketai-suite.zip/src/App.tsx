/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Activity, LogOut, Moon, Sun, Globe } from 'lucide-react';
import Home from './components/Home';
import CampaignGenerator from './components/CampaignGenerator';
import PitchGenerator from './components/PitchGenerator';
import LeadQualifier from './components/LeadQualifier';
import Login from './components/Login';
import About from './components/About';
import ChatBot from './components/ChatBot';
import MarketingNews from './components/MarketingNews';
import Profile from './components/Profile';
import { useLanguage, Language } from './contexts/LanguageContext';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentTab, setCurrentTab] = useState('home');
  const [isDark, setIsDark] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  const renderContent = () => {
    switch (currentTab) {
      case 'home':
        return <Home onNavigate={setCurrentTab} />;
      case 'about':
        return <About />;
      case 'campaign':
        return <CampaignGenerator />;
      case 'pitch':
        return <PitchGenerator />;
      case 'lead':
        return <LeadQualifier />;
      case 'news':
        return <MarketingNews />;
      case 'profile':
        return <Profile />;
      default:
        return <Home onNavigate={setCurrentTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-fuchsia-500 dark:from-slate-900 dark:via-indigo-950 dark:to-slate-900 text-white font-sans transition-colors duration-500">
      <header className="px-8 py-6 flex justify-between items-center border-b border-white/10">
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => setCurrentTab('home')}
        >
          <Activity className="w-8 h-8" />
          <h1 className="text-2xl font-bold tracking-tight">MarketAI Suite</h1>
        </div>
        <nav className="flex items-center gap-6 text-sm font-medium">
          <button 
            onClick={() => setCurrentTab('home')}
            className={`hover:text-white transition-colors ${currentTab === 'home' ? 'text-white' : 'text-white/70'}`}
          >
            {t('home')}
          </button>
          <button 
            onClick={() => setCurrentTab('about')}
            className={`hover:text-white transition-colors ${currentTab === 'about' ? 'text-white' : 'text-white/70'}`}
          >
            {t('about')}
          </button>
          <button 
            onClick={() => setCurrentTab('campaign')}
            className={`hover:text-white transition-colors ${currentTab === 'campaign' ? 'text-white' : 'text-white/70'}`}
          >
            {t('campaign')}
          </button>
          <button 
            onClick={() => setCurrentTab('pitch')}
            className={`hover:text-white transition-colors ${currentTab === 'pitch' ? 'text-white' : 'text-white/70'}`}
          >
            {t('pitch')}
          </button>
          <button 
            onClick={() => setCurrentTab('lead')}
            className={`hover:text-white transition-colors ${currentTab === 'lead' ? 'text-white' : 'text-white/70'}`}
          >
            {t('lead')}
          </button>
          <button 
            onClick={() => setCurrentTab('news')}
            className={`hover:text-white transition-colors ${currentTab === 'news' ? 'text-white' : 'text-white/70'}`}
          >
            {t('news')}
          </button>
          <button 
            onClick={() => setCurrentTab('profile')}
            className={`hover:text-white transition-colors ${currentTab === 'profile' ? 'text-white' : 'text-white/70'}`}
          >
            {t('profile')}
          </button>
          <div className="flex items-center gap-4 ml-4 border-l border-white/20 pl-6">
            <div className="relative group flex items-center gap-2">
              <Globe className="w-4 h-4 text-white/70" />
              <select 
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-transparent text-white/70 hover:text-white text-sm focus:outline-none cursor-pointer appearance-none pr-4"
              >
                <option value="English" className="text-slate-900">English</option>
                <option value="Spanish" className="text-slate-900">Español</option>
                <option value="French" className="text-slate-900">Français</option>
                <option value="German" className="text-slate-900">Deutsch</option>
                <option value="Chinese" className="text-slate-900">中文</option>
                <option value="Hindi" className="text-slate-900">हिन्दी (Hindi)</option>
                <option value="Telugu" className="text-slate-900">తెలుగు (Telugu)</option>
                <option value="Tamil" className="text-slate-900">தமிழ் (Tamil)</option>
                <option value="Kannada" className="text-slate-900">ಕನ್ನಡ (Kannada)</option>
                <option value="Malayalam" className="text-slate-900">മലയാളം (Malayalam)</option>
                <option value="Bengali" className="text-slate-900">বাংলা (Bengali)</option>
                <option value="Marathi" className="text-slate-900">मराठी (Marathi)</option>
                <option value="Gujarati" className="text-slate-900">ગુજરાતી (Gujarati)</option>
              </select>
            </div>
            <button 
              onClick={() => setIsDark(!isDark)}
              className="hover:text-white transition-colors text-white/70"
              title="Toggle Dark Mode"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button 
              onClick={() => setIsAuthenticated(false)}
              className="flex items-center gap-2 hover:text-white transition-colors text-white/70"
            >
              <LogOut className="w-4 h-4" />
              {t('signOut')}
            </button>
          </div>
        </nav>
      </header>

      <main className="p-8 max-w-6xl mx-auto">
        {renderContent()}
      </main>
    </div>
  );
}
